import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Board of Directors",
  description: "FAUNA is guided by a volunteer Board of Directors committed to responsible governance, community partnership, animal welfare, and the long-term s",
}

export default function Page() {
  return (
    <main>
      <section className="bg-gradient-to-br from-[#061424] to-[#0a1e3d] px-6 py-20 text-white">
        <div className="mx-auto max-w-5xl">
          <p className="font-script text-4xl text-[#8AFF00]">Leadership</p>
          <h1 className="mt-2 text-4xl font-extrabold md:text-6xl">Board of Directors</h1>
        </div>
      </section>
      <section className="px-6 py-16">
        <div className="mx-auto max-w-4xl rounded-3xl border border-sky-100 bg-white p-8 shadow-sm md:p-12">
          <p className="text-lg leading-8 text-gray-700">FAUNA is guided by a volunteer Board of Directors committed to responsible governance, community partnership, animal welfare, and the long-term sustainability of our lifesaving work. Board member profiles can be added here as they are approved for publication.</p>
        </div>
      </section>
    </main>
  )
}
