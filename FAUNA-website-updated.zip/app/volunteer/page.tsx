import type { Metadata } from "next"
import Link from "next/link"
import { ExternalLink, HeartHandshake } from "lucide-react"
import { Button } from "@/components/ui/button"

export const metadata: Metadata = {
  title: "Volunteer with FAUNA",
  description: "Volunteer opportunities supporting FAUNA's animals, programs, and community events.",
}

const roles = [
  ["Animal Care", "Help with cleaning, feeding, enrichment, bathing, and daily care for animals."],
  ["Foster Support", "Provide temporary care or help foster families with supplies, transport, and coordination."],
  ["Events & Outreach", "Represent FAUNA at adoption events, fundraisers, health fairs, and community programs."],
  ["Veterinary Assistant", "Assist with vaccines, blood tests and nail clipping during onboarding, community health fairs and bath days."],
  ["Transport", "Help animals reach veterinary appointments, foster homes, adoption events, and rescue partners."],
  ["Administrative Support", "Contribute photography, data entry, fundraising, communications, or other professional skills."],
]

export default function VolunteerPage() {
  return (
    <main>
      <section className="bg-[#8AFF00] px-6 py-20 text-[#0a1e3d]">
        <div className="mx-auto max-w-5xl">
          <p className="font-script text-4xl">Give your time</p>
          <h1 className="mt-2 text-4xl font-extrabold md:text-6xl">Volunteer with FAUNA</h1>
          <p className="mt-5 max-w-3xl text-lg leading-8">
            Volunteers make lifesaving care, community outreach, and second chances possible.
          </p>
        </div>
      </section>
      <section className="px-6 py-16">
        <div className="mx-auto max-w-6xl">
          <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {roles.map(([title, body]) => (
              <article key={title} className="rounded-3xl border border-sky-100 bg-white p-7 shadow-sm">
                <HeartHandshake className="h-8 w-8 text-[#0099FF]" />
                <h2 className="mt-4 text-2xl font-bold text-[#0a1e3d]">{title}</h2>
                <p className="mt-3 leading-7 text-gray-600">{body}</p>
              </article>
            ))}
          </div>
          <div className="mt-12 text-center">
            <Link href="https://new.shelterluv.com/form/community/FAUN/14823" target="_blank" rel="noopener noreferrer">
              <Button className="bg-[#0099FF] px-7 py-6 text-base font-bold text-white hover:bg-[#0088ee]">
                Complete the Volunteer Form <ExternalLink className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
