import type { Metadata } from "next"
import Link from "next/link"
import { Briefcase, ExternalLink, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"

export const metadata: Metadata = {
  title: "Employment Opportunities",
  description: "Explore employment opportunities with FAUNA in Natchitoches, Louisiana.",
}

export default function EmploymentPage() {
  return (
    <main>
      <section className="bg-gradient-to-br from-[#061424] to-[#0a1e3d] px-6 py-20 text-white">
        <div className="mx-auto max-w-6xl">
          <p className="font-script text-4xl text-[#8AFF00]">Build a lifesaving future</p>
          <h1 className="mt-2 text-4xl font-extrabold md:text-6xl">Employment Opportunities</h1>
        </div>
      </section>

      <section className="px-6 py-16">
        <div className="mx-auto max-w-5xl">
          <article className="rounded-3xl border-2 border-[#33CCCC]/30 bg-white p-8 shadow-lg md:p-10">
            <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
              <div>
                <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-[#8AFF00]/20">
                  <Briefcase className="h-7 w-7 text-[#0a1e3d]" />
                </div>
                <p className="text-sm font-bold uppercase tracking-wider text-[#0099FF]">Open Position</p>
                <h2 className="mt-2 text-3xl font-extrabold text-[#0a1e3d]">Executive Director of Shelter Operations</h2>
                <p className="mt-4 max-w-3xl text-lg leading-8 text-gray-600">
                  Lead shelter operations, staff development, animal care, community partnerships, and the launch of the Edwina &amp; Sam Friedman Pet Adoption &amp; Welfare Center.
                </p>
              </div>
              <Link href="https://fauna.bamboohr.com/careers/23" target="_blank" rel="noopener noreferrer" className="shrink-0">
                <Button className="bg-[#0099FF] font-bold text-white hover:bg-[#0088ee]">
                  View Job Posting <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </article>

          <section className="mt-16">
            <p className="font-script text-center text-4xl text-[#33CCCC]">Purpose-driven work</p>
            <h2 className="mt-2 text-center text-3xl font-extrabold text-[#0a1e3d]">Why Work with FAUNA?</h2>
            <div className="mt-8 grid gap-5 md:grid-cols-3">
              {[
                ["Meaningful Impact", "Help create better outcomes for homeless and neglected animals throughout Natchitoches Parish."],
                ["Community Partnership", "Work alongside volunteers, donors, veterinary partners, and animal welfare advocates."],
                ["A Growing Organization", "Help shape programs and operations during an important period of growth for FAUNA."],
              ].map(([title, body]) => (
                <article key={title} className="rounded-2xl bg-sky-50 p-6">
                  <h3 className="text-xl font-bold text-[#0a1e3d]">{title}</h3>
                  <p className="mt-2 leading-7 text-gray-600">{body}</p>
                </article>
              ))}
            </div>
          </section>

          <section className="mt-16 rounded-3xl bg-[#8AFF00] p-9 text-center text-[#0a1e3d]">
            <Heart className="mx-auto h-10 w-10" />
            <h2 className="mt-3 text-3xl font-extrabold">Not Ready for a Job?</h2>
            <Link href="/volunteer">
              <Button className="mt-6 bg-[#0a1e3d] font-bold text-white hover:bg-[#061424]">
                Volunteer with FAUNA
              </Button>
            </Link>
          </section>
        </div>
      </section>
    </main>
  )
}
