import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "History",
  description: "For decades, dedicated volunteers have worked to improve the lives of homeless animals in Natchitoches Parish, laying the foundation for what is ",
}

export default function Page() {
  return (
    <main>
      <section className="bg-gradient-to-br from-[#061424] to-[#0a1e3d] px-6 py-20 text-white">
        <div className="mx-auto max-w-5xl">
          <p className="font-script text-4xl text-[#8AFF00]">Our story</p>
          <h1 className="mt-2 text-4xl font-extrabold md:text-6xl">History</h1>
        </div>
      </section>
      <section className="px-6 py-16">
        <div className="mx-auto max-w-4xl rounded-3xl border border-sky-100 bg-white p-8 shadow-sm md:p-12">
          <p className="text-lg leading-8 text-gray-700">For decades, dedicated volunteers have worked to improve the lives of homeless animals in Natchitoches Parish, laying the foundation for what is now FAUNA. Today, FAUNA continues that legacy by bringing together volunteers, donors, and public and private partners to create lasting change for vulnerable animals.</p>
        </div>
      </section>
    </main>
  )
}
