import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Advisory Board",
  description: "FAUNA's Advisory Board brings together community leaders and subject-matter experts who provide guidance, perspective, and support as the organiz",
}

export default function Page() {
  return (
    <main>
      <section className="bg-gradient-to-br from-[#061424] to-[#0a1e3d] px-6 py-20 text-white">
        <div className="mx-auto max-w-5xl">
          <p className="font-script text-4xl text-[#8AFF00]">Community expertise</p>
          <h1 className="mt-2 text-4xl font-extrabold md:text-6xl">Advisory Board</h1>
        </div>
      </section>
      <section className="px-6 py-16">
        <div className="mx-auto max-w-4xl rounded-3xl border border-sky-100 bg-white p-8 shadow-sm md:p-12">
          <p className="text-lg leading-8 text-gray-700">FAUNA's Advisory Board brings together community leaders and subject-matter experts who provide guidance, perspective, and support as the organization expands its programs and prepares for the Edwina & Sam Friedman Pet Adoption & Welfare Center.</p>
        </div>
      </section>
    </main>
  )
}
