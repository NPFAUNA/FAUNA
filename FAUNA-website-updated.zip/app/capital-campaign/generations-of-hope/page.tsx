import type { Metadata } from "next"
import Link from "next/link"
import { Heart, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

export const metadata: Metadata = {
  title: "Generations of Hope Campaign",
  description: "Support the Generations of Hope Campaign for the Edwina & Sam Friedman Pet Adoption & Welfare Center.",
}

export default function CampaignPage() {
  return (
    <main>
      <section className="bg-[#8AFF00] px-6 py-20 text-[#0a1e3d]">
        <div className="mx-auto max-w-5xl text-center">
          <p className="font-script text-4xl">A legacy of second chances</p>
          <h1 className="mt-2 text-4xl font-extrabold md:text-6xl">Generations of Hope Campaign</h1>
          <p className="mx-auto mt-5 max-w-3xl text-lg leading-8">
            Help create and sustain the Edwina &amp; Sam Friedman Pet Adoption &amp; Welfare Center for generations to come.
          </p>
        </div>
      </section>

      <section className="px-6 py-16">
        <div className="mx-auto max-w-5xl">
          <div className="rounded-3xl border border-sky-100 bg-white p-8 shadow-sm md:p-12">
            <Sparkles className="h-10 w-10 text-[#0099FF]" />
            <h2 className="mt-4 text-3xl font-extrabold text-[#0a1e3d]">Naming Campaign</h2>
            <p className="mt-4 text-xl leading-8 text-gray-700">
              Your name, or the name of a person or pet you love, can be forever honored where second chances begin.
            </p>

            <h3 className="mt-10 text-2xl font-bold text-[#0a1e3d]">The Impact of Your Gift:</h3>
            <ul className="mt-5 space-y-4 text-lg leading-8 text-gray-700">
              <li className="flex gap-3"><Heart className="mt-1 h-6 w-6 shrink-0 text-[#0099FF]" />Building a permanent endowment to sustain the Friedman Center&apos;s mission for generations.</li>
              <li className="flex gap-3"><Heart className="mt-1 h-6 w-6 shrink-0 text-[#0099FF]" />Providing advanced medical equipment, safe housing, and equipment for enriching outdoor play yards and spaces where animals can heal and thrive.</li>
              <li className="flex gap-3"><Heart className="mt-1 h-6 w-6 shrink-0 text-[#0099FF]" />Supporting the dedicated staff, essential supplies, and lifesaving programs that give homeless animals the care they need and the second chances they deserve.</li>
            </ul>
          </div>

          <div className="mt-10 rounded-3xl bg-[#0a1e3d] p-9 text-center text-white">
            <h2 className="text-3xl font-extrabold">Support the Campaign</h2>
            <p className="mx-auto mt-3 max-w-2xl text-gray-300">
              Your contribution helps turn a permanent center for animal welfare into a lasting community resource.
            </p>
            <Link href="/donate">
              <Button className="mt-7 bg-[#8AFF00] px-8 font-bold text-[#0a1e3d] hover:bg-[#7aee00]">Make a Gift</Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
