import type { Metadata } from "next"
import Link from "next/link"
import { ArrowRight, Newspaper } from "lucide-react"
import { Button } from "@/components/ui/button"

export const metadata: Metadata = {
  title: "Edwina & Sam Friedman Pet Adoption & Welfare Center",
  description: "Learn about FAUNA's future Edwina & Sam Friedman Pet Adoption & Welfare Center.",
}

export default function FriedmanCenterPage() {
  return (
    <main>
      <section className="bg-gradient-to-br from-[#061424] to-[#0a1e3d] px-6 py-20 text-white">
        <div className="mx-auto max-w-6xl text-center">
          <div className="mx-auto mb-5 inline-flex rounded-full bg-[#8AFF00] px-5 py-2 font-bold text-[#0a1e3d]">
            Coming Fall 2026
          </div>
          <p className="font-script text-4xl text-[#33CCCC]">Hope has an address</p>
          <h1 className="mx-auto mt-2 max-w-5xl text-4xl font-extrabold md:text-6xl">
            Edwina &amp; Sam Friedman Pet Adoption &amp; Welfare Center
          </h1>
        </div>
      </section>

      <section className="px-6 py-16">
        <div className="mx-auto max-w-5xl">
          <h2 className="text-3xl font-extrabold text-[#0a1e3d]">From Grassroots Rescue to Parish-Wide Lifesaving</h2>
          <div className="mt-6 space-y-5 text-lg leading-8 text-gray-700">
            <p>
              For decades, dedicated volunteers have worked to improve the lives of homeless animals in Natchitoches Parish, laying the foundation for what is now FAUNA. Today, we continue that legacy by implementing innovative programs and bringing together volunteers, donors, and public and private partners in a community that refuses to give up on its vulnerable animals.
            </p>
            <p>
              FAUNA has helped reduce the euthanasia rate in Natchitoches Parish, placed thousands of animals in loving homes, expanded access to free and low-cost vaccinations and spay/neuter services, and provided Trap-Neuter-Return (TNR) for community cats, improving the lives of both animals and the people who care for them.
            </p>
            <p>
              But every milestone brings a new challenge. Our current makeshift structures have reached their limits and can no longer support the growing needs of the animals and people we serve. The Edwina &amp; Sam Friedman Pet Adoption &amp; Welfare Center will allow us to save more lives, expand our outreach programs, and deliver hope throughout Natchitoches Parish for generations to come.
            </p>
          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {[
              ["Compassionate Animal Care", "Purpose-designed spaces for safe housing, recovery, enrichment, and adoption."],
              ["Community Wellness", "Expanded access to low-cost services, education, and responsible pet ownership resources."],
              ["Stronger Partnerships", "A permanent home for collaboration among staff, volunteers, donors, and community partners."],
            ].map(([title, body]) => (
              <article key={title} className="rounded-3xl bg-sky-50 p-7">
                <h3 className="text-xl font-bold text-[#0a1e3d]">{title}</h3>
                <p className="mt-3 leading-7 text-gray-600">{body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#8AFF00] px-6 py-14 text-center text-[#0a1e3d]">
        <h2 className="text-3xl font-extrabold">Because of Edwina and Sam Friedman, HOPE now has an address.</h2>
        <p className="mx-auto mt-4 max-w-4xl text-lg leading-8">
          Their extraordinary gift transformed a dream into a lasting legacy and created a place where every animal who enters and every community member who walks through its doors finds compassion, care, safety, and second chances.
        </p>
      </section>

      <section className="px-6 py-16">
        <div className="mx-auto max-w-5xl">
          <div className="flex items-center gap-3">
            <Newspaper className="h-8 w-8 text-[#0099FF]" />
            <h2 className="text-3xl font-extrabold text-[#0a1e3d]">In the News</h2>
          </div>
          <p className="mt-4 text-lg text-gray-600">
            Follow FAUNA on social media for construction milestones, community announcements, and Friedman Center updates.
          </p>

          <div className="mt-12 rounded-3xl bg-[#0a1e3d] p-9 text-center text-white">
            <p className="font-script text-4xl text-[#8AFF00]">Generations of Hope</p>
            <h2 className="mt-2 text-3xl font-extrabold">Help build a lasting legacy</h2>
            <p className="mx-auto mt-4 max-w-2xl text-gray-300">
              Learn about the campaign, naming opportunities, and the impact your gift can make.
            </p>
            <Link href="/capital-campaign/generations-of-hope">
              <Button className="mt-7 h-14 bg-[#8AFF00] px-9 text-lg font-extrabold text-[#0a1e3d] hover:bg-[#7aee00]">
                View the Capital Campaign <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
