import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Mail, MapPin, Music2 } from "lucide-react"

const socialLinks = [
  { href: "https://www.facebook.com/FaunaNatchitoches", label: "Facebook", icon: Facebook },
  { href: "https://www.instagram.com/fauna_natchitoches/", label: "Instagram", icon: Instagram },
  { href: "https://www.tiktok.com/@faunanatchitochesrescue?is_from_webapp=1&sender_device=pc", label: "TikTok", icon: Music2 },
]

export function Footer() {
  return (
    <footer className="bg-[#061424] text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-12 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <Image
            src="/fauna-logo.png"
            alt="FAUNA"
            width={150}
            height={150}
            className="mb-5 h-28 w-auto object-contain"
          />
          <p className="max-w-md text-sm leading-6 text-gray-300">
            A 501(c)(3) nonprofit dedicated to providing humane care for homeless animals in
            Natchitoches Parish, Louisiana - We are a voice for those creatures who cannot speak for themselves.
          </p>
          <div className="mt-6 flex gap-3">
            {socialLinks.map(({ href, label, icon: Icon }) => (
              <Link
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={label}
                className="flex h-12 w-12 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-[#0099FF]"
              >
                <Icon className="h-6 w-6" />
              </Link>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-4 font-script text-3xl text-[#8AFF00]">Explore</h2>
          <div className="grid gap-2 text-sm text-gray-300">
            <Link href="/" className="hover:text-white">About FAUNA</Link>
            <Link href="/programs" className="hover:text-white">Programs</Link>
            <Link href="/adopt-foster" className="hover:text-white">Adopt or Foster</Link>
            <Link href="/events" className="hover:text-white">Events</Link>
            <Link href="/volunteer" className="hover:text-white">Volunteer</Link>
            <Link href="/donate" className="hover:text-white">Donate</Link>
          </div>
        </div>

        <div>
          <h2 className="mb-4 font-script text-3xl text-[#33CCCC]">Contact</h2>
          <div className="space-y-4 text-sm text-gray-300">
            <a href="mailto:rescue@npfauna.org" className="flex items-start gap-3 hover:text-white">
              <Mail className="mt-0.5 h-5 w-5 shrink-0 text-[#33CCCC]" />
              rescue@npfauna.org
            </a>
            <div className="flex items-start gap-3">
              <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-[#33CCCC]" />
              <span>FAUNA, P.O. Box 2552<br />Natchitoches, LA 71457</span>
            </div>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 px-6 py-5 text-center text-xs text-gray-400">
        &copy; {new Date().getFullYear()} Friends All United for Natchitoches Animals. All rights reserved.
      </div>
    </footer>
  )
}
