"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { ChevronDown, Heart, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

const aboutItems = [
  { href: "/", label: "About FAUNA" },
  { href: "/history", label: "History" },
  { href: "/board-of-directors", label: "Board of Directors" },
  { href: "/advisory-board", label: "Advisory Board" },
  { href: "/employment", label: "Employment Opportunities" },
  { href: "/volunteer", label: "Volunteer with FAUNA" },
]

const programItems = [
  { href: "/programs", label: "Programs Overview" },
  { href: "/programs/spay-natchitoches", label: "Spay Natchitoches" },
  { href: "/programs/tnr", label: "TNR Program" },
]

const navItems = [
  { href: "/adopt-foster", label: "Adopt or Foster" },
  { href: "/events", label: "Events" },
  { href: "/capital-campaign", label: "Friedman Center" },
  { href: "/resources", label: "Resources" },
]

export function Navbar() {
  const [open, setOpen] = useState(false)
  const [mobileGroup, setMobileGroup] = useState<string | null>(null)
  const pathname = usePathname()

  const active = (href: string) =>
    href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`)

  return (
    <nav className="sticky top-0 z-50 border-b border-sky-100 bg-white shadow-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex min-h-20 items-center justify-between gap-4">
          <Link href="/" className="flex shrink-0 items-center py-2" aria-label="FAUNA home">
            <Image
              src="/fauna-logo.png"
              alt="FAUNA - Friends All United for Natchitoches Animals"
              width={82}
              height={82}
              className="h-16 w-auto object-contain"
              priority
            />
          </Link>

          <div className="hidden items-center gap-0.5 lg:flex">
            <DesktopMenu label="About" items={aboutItems} pathname={pathname} />
            <DesktopMenu label="Programs" items={programItems} pathname={pathname} />
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  active(item.href)
                    ? "bg-sky-100 font-semibold text-[#0099FF]"
                    : "text-gray-600 hover:bg-sky-50 hover:text-[#0099FF]"
                )}
              >
                {item.label}
              </Link>
            ))}
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <Link href="/donate" className="hidden sm:block">
              <Button className="h-10 bg-[#8AFF00] px-5 font-bold text-[#0a1e3d] hover:bg-[#7aee00]">
                <Heart className="mr-1.5 h-4 w-4" />
                Donate
              </Button>
            </Link>
            <button
              onClick={() => setOpen(!open)}
              className="rounded-md p-2 text-gray-600 hover:bg-gray-100 lg:hidden"
              aria-label="Toggle menu"
              aria-expanded={open}
            >
              {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {open && (
        <div className="border-t border-gray-100 bg-white px-4 pb-5 pt-2 shadow-lg lg:hidden">
          <MobileMenu
            label="About"
            items={aboutItems}
            expanded={mobileGroup === "about"}
            onToggle={() => setMobileGroup(mobileGroup === "about" ? null : "about")}
            onNavigate={() => setOpen(false)}
          />
          <MobileMenu
            label="Programs"
            items={programItems}
            expanded={mobileGroup === "programs"}
            onToggle={() => setMobileGroup(mobileGroup === "programs" ? null : "programs")}
            onNavigate={() => setOpen(false)}
          />
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className={cn(
                "block rounded-md px-3 py-2.5 text-sm font-medium",
                active(item.href)
                  ? "bg-sky-100 font-semibold text-[#0099FF]"
                  : "text-gray-600 hover:bg-sky-50 hover:text-[#0099FF]"
              )}
            >
              {item.label}
            </Link>
          ))}
          <Link href="/donate" onClick={() => setOpen(false)}>
            <Button className="mt-3 w-full bg-[#8AFF00] font-bold text-[#0a1e3d] hover:bg-[#7aee00]">
              <Heart className="mr-2 h-4 w-4" />
              Donate
            </Button>
          </Link>
        </div>
      )}
    </nav>
  )
}

function DesktopMenu({
  label,
  items,
  pathname,
}: {
  label: string
  items: { href: string; label: string }[]
  pathname: string
}) {
  const isActive = items.some((item) =>
    item.href === "/" ? pathname === "/" : pathname === item.href || pathname.startsWith(`${item.href}/`)
  )

  return (
    <div className="group relative">
      <button
        className={cn(
          "flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium transition-colors",
          isActive
            ? "bg-sky-100 font-semibold text-[#0099FF]"
            : "text-gray-600 hover:bg-sky-50 hover:text-[#0099FF]"
        )}
      >
        {label}
        <ChevronDown className="h-3.5 w-3.5 transition-transform group-hover:rotate-180" />
      </button>
      <div className="invisible absolute left-0 top-full z-50 min-w-64 translate-y-1 rounded-xl border border-sky-100 bg-white p-2 opacity-0 shadow-xl transition-all group-hover:visible group-hover:translate-y-0 group-hover:opacity-100">
        {items.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className="block rounded-lg px-3 py-2 text-sm text-gray-700 hover:bg-sky-50 hover:text-[#0099FF]"
          >
            {item.label}
          </Link>
        ))}
      </div>
    </div>
  )
}

function MobileMenu({
  label,
  items,
  expanded,
  onToggle,
  onNavigate,
}: {
  label: string
  items: { href: string; label: string }[]
  expanded: boolean
  onToggle: () => void
  onNavigate: () => void
}) {
  return (
    <div>
      <button
        onClick={onToggle}
        className="flex w-full items-center justify-between rounded-md px-3 py-2.5 text-sm font-semibold text-gray-700 hover:bg-sky-50"
        aria-expanded={expanded}
      >
        {label}
        <ChevronDown className={cn("h-4 w-4 transition-transform", expanded && "rotate-180")} />
      </button>
      {expanded && (
        <div className="mb-2 ml-3 border-l-2 border-[#33CCCC]/40 pl-2">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className="block rounded-md px-3 py-2 text-sm text-gray-600 hover:bg-sky-50 hover:text-[#0099FF]"
            >
              {item.label}
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
