"use client"

import { useEffect, useState } from "react"
import { Mail, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function EmailSignupPopup() {
  const [open, setOpen] = useState(false)

  useEffect(() => {
    if (!window.localStorage.getItem("fauna-email-popup-seen")) {
      const timer = window.setTimeout(() => setOpen(true), 900)
      return () => window.clearTimeout(timer)
    }
  }, [])

  const close = () => {
    window.localStorage.setItem("fauna-email-popup-seen", "true")
    setOpen(false)
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#061424]/70 p-4" role="dialog" aria-modal="true" aria-labelledby="email-signup-title">
      <div className="relative w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl">
        <button onClick={close} className="absolute right-4 top-4 rounded-full p-2 text-gray-500 hover:bg-gray-100" aria-label="Close email signup">
          <X className="h-5 w-5" />
        </button>
        <div className="bg-[#8AFF00] px-8 py-7 text-center">
          <Mail className="mx-auto mb-3 h-10 w-10 text-[#0a1e3d]" />
          <p className="font-script text-3xl text-[#0a1e3d]">Stay connected</p>
          <h2 id="email-signup-title" className="mt-1 text-3xl font-extrabold text-[#0a1e3d]">Join Our Email List</h2>
        </div>
        <div className="px-8 py-7 text-center">
          <p className="mb-5 leading-relaxed text-gray-600">
            Get rescue stories, event announcements, volunteer opportunities, and lifesaving updates from FAUNA.
          </p>
          <a href="mailto:rescue@npfauna.org?subject=Join%20FAUNA%20Email%20List">
            <Button onClick={close} className="w-full bg-[#0099FF] font-bold text-white hover:bg-[#0088ee]">
              Sign Me Up
            </Button>
          </a>
          <button onClick={close} className="mt-4 text-sm text-gray-500 underline-offset-4 hover:underline">
            Maybe later
          </button>
        </div>
      </div>
    </div>
  )
}
